# Tubig ICO Smart Contract

## Common

This is an implementation of the Ethereum ERC20 smart-contract is used by project Tubig

<b>Plugins / 3rd party tools:</b>

[https://github.com/OpenZeppelin/zeppelin-solidity/](https://github.com/OpenZeppelin/zeppelin-solidity/)

[https://github.com/TokenMarketNet/ico](https://github.com/TokenMarketNet/ico)